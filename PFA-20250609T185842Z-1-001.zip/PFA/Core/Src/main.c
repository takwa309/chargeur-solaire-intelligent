/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include <string.h>
#include "INA219.h"
#include "ssd1306.h"
#define ADR_INA219_Panneau (0x40 << 1)  // INA219 #1 (ADDR = GND)
#define ADR_INA219_Battery (0x41 << 1)  // INA219 #2 (ADDR = VCC)
#define OLED (0x3C << 1)  // Ecran


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;

osThreadId TaskMPPTHandle;
osThreadId TaskINA_PanneauHandle;
osThreadId TaskSourceSwitcHandle;
osThreadId TaskDisplayHandle;
osThreadId TaskWiFiHandle;
osThreadId TaskINA_BatterrHandle;
osMessageQId Q_BatteryHandle;

QueueHandle_t Q_Panneau_Data;
QueueHandle_t Q_wifi;

INA219_t INA219_Panneau  = {
    .ina219_i2c = &hi2c1,
    .Address = ADR_INA219_Panneau     // 0x40<<1
};
INA219_t INA219_Battery  = {
    .ina219_i2c = &hi2c1,
    .Address = ADR_INA219_Battery     // 0x41<<1
};

typedef struct {
   uint16_t  tension_batterie;
   uint16_t  intensite_batterie;
   uint16_t  batterie_percent;
} BatterieData_t;


/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
void MPPT(void const * argument);
void INA_Panneau(void const * argument);
void SourceSwitch(void const * argument);
void Display(void const * argument);
void WiFi(void const * argument);
void INA_Batterry(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of Q_Battery */
  osMessageQDef(Q_Battery, 1, uint16_t);
  Q_BatteryHandle = osMessageCreate(osMessageQ(Q_Battery), NULL);

  /* definition and creation of Q_wifi */
  Q_wifi = xQueueCreate(1, sizeof(BatterieData_t));

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  Q_Panneau_Data= xQueueCreate(10, sizeof(uint16_t[2]));

  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of TaskMPPT */
  osThreadDef(TaskMPPT, MPPT, osPriorityNormal, 0, 128);
  TaskMPPTHandle = osThreadCreate(osThread(TaskMPPT), NULL);

  /* definition and creation of TaskINA_Panneau */
  osThreadDef(TaskINA_Panneau, INA_Panneau, osPriorityNormal, 0, 128);
  TaskINA_PanneauHandle = osThreadCreate(osThread(TaskINA_Panneau), NULL);

  /* definition and creation of TaskSourceSwitc */
  osThreadDef(TaskSourceSwitc, SourceSwitch, osPriorityNormal, 0, 128);
  TaskSourceSwitcHandle = osThreadCreate(osThread(TaskSourceSwitc), NULL);

  /* definition and creation of TaskDisplay */
  osThreadDef(TaskDisplay, Display, osPriorityIdle, 0, 128);
  TaskDisplayHandle = osThreadCreate(osThread(TaskDisplay), NULL);

  /* definition and creation of TaskWiFi */
  osThreadDef(TaskWiFi, WiFi, osPriorityIdle, 0, 128);
  TaskWiFiHandle = osThreadCreate(osThread(TaskWiFi), NULL);

  /* definition and creation of TaskINA_Batterr */
  osThreadDef(TaskINA_Batterr, INA_Batterry, osPriorityNormal, 0, 128);
  TaskINA_BatterrHandle = osThreadCreate(osThread(TaskINA_Batterr), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 83;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 99;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 50;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin : PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_MPPT */
/**
  * @brief  Function implementing the TaskMPPT thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_MPPT */
void MPPT(void const * argument)
{
  /* USER CODE BEGIN 5 */


	uint16_t panneau_data[2];
	float voltage_panneau, current_panneau;
	float power, previous_power = 0.0f;
	int16_t duty_cycle = 50; // Commencer à 50% de PWM
	int8_t pwm_direction = 1; // 1 = augmenter, -1 = diminuer
	// Initialisation PWM
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, duty_cycle);
  /* Infinite loop */
  for(;;)
  {
	  if (xQueueReceive(Q_Panneau_Data, &panneau_data, portMAX_DELAY) == pdTRUE)
	   {
	     // Convert Data
	     voltage_panneau = panneau_data[0] / 1000.0f;  // Convert to Volts
	     current_panneau = panneau_data[1] / 100.0f;  // Convert to Amps
	     // Calculate power (P = V * I)
	     power = voltage_panneau * current_panneau;
	     // Protection : limiter le courant maximum
	                if (current_panneau > 1.0f) // 1A max pour protéger la batterie et TP4056
	                {
	                    duty_cycle -= 5; // Diminuer duty cycle
	                    if (duty_cycle < 5) duty_cycle = 5; // Ne pas descendre trop bas
	                }
	                else
	                {
	                    // Logique MPPT :			 Perturb & Observe
	                    if (power > previous_power)
	                    {     duty_cycle += pwm_direction * 5;
	                    }
	                    else
	                    {
	                        // Si la puissance diminue, inverser la direction
	                        pwm_direction = -pwm_direction;
	                        duty_cycle += pwm_direction * 5;
	                    }
	                }
	                // Clamper le duty cycle entre 5% et 95%
	                if (duty_cycle > 95) duty_cycle = 95;
	                if (duty_cycle < 5) duty_cycle = 5;
	                // Appliquer le nouveau duty cycle
	                __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, duty_cycle);
	                previous_power = power;
	            }
	   // Delay for the next MPPT iteration
	   vTaskDelay(pdMS_TO_TICKS(200));
	  }

  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_INA_Panneau */
/**
* @brief Function implementing the TaskINA_Panneau thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_INA_Panneau */
void INA_Panneau(void const * argument)
{
  /* USER CODE BEGIN INA_Panneau */
  for(;;)
  {


      uint16_t voltage_panneau = INA219_ReadBusVoltage(&INA219_Panneau);
      int16_t current_panneau = INA219_ReadCurrent(&INA219_Panneau);

      // Data to put into Queue
      uint16_t panneau_data[2] = {voltage_panneau, current_panneau};


      xQueueOverwrite(Q_Panneau_Data, &panneau_data);

      // Delay for next reading (500ms)
      vTaskDelay(pdMS_TO_TICKS(500));

  }
  /* USER CODE END INA_Panneau */
}

/* USER CODE BEGIN Header_SourceSwitch */
/**
* @brief Function implementing the TaskSourceSwitc thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_SourceSwitch */
void SourceSwitch(void const * argument)
{
  /* USER CODE BEGIN SourceSwitch */
	uint16_t panneau_data[2];
	float voltage_panneau;

  /* Infinite loop */
  for(;;)
  {
	  if (xQueueReceive(Q_Panneau_Data, &panneau_data, portMAX_DELAY) == pdTRUE)
	 	    {
	 	      // Convert Data
	 	      voltage_panneau = panneau_data[0] / 1000.0f;  // Convert to Volts
	 	      // Check conditions to switch sources (solar vs adapter)
	 	      if (voltage_panneau >= 6.5f )
	 	      {
	 	        // If solar panel voltage is above a certain threshold and battery is not full, switch to solar
	 	        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);  // Switch to solar power
	 	      }
	 	      else
	 	      {
	 	        // Otherwise, switch to adapter power
	 	        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);  // Switch to adapter power
	 	      }
	 	    }
	 	    // Delay for the next switch check
	 	    vTaskDelay(pdMS_TO_TICKS(500));
	 	  }


  /* USER CODE END SourceSwitch */

}
/* USER CODE BEGIN Header_Display */
/**
* @brief Function implementing the TaskDisplay thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Display */
void Display(void const * argument)
{
  /* USER CODE BEGIN Display */
    uint16_t battery_level = 0;
    char buffer[20];

    for(;;)
    {
        if (xQueueReceive(Q_BatteryHandle, &battery_level, portMAX_DELAY) == pdTRUE)
        {

                ssd1306_Fill(Black); // Effacer l'écran
                ssd1306_SetCursor(0, 0); // Positionner le curseur en haut à gauche

                // Préparer le texte à afficher
                sprintf(buffer, "Battery: %d%%", battery_level);
                ssd1306_WriteString(buffer, Font_7x10, White); // Afficher le texte

                // Mettre à jour l'écran
                ssd1306_UpdateScreen(&hi2c1); // Attention : passe bien ton handle I2C ici

            }
        }

  /* USER CODE END Display */
}

/* USER CODE BEGIN Header_WiFi */
/**
* @brief Function implementing the TaskWiFi thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_WiFi */
void WiFi(void const * argument)
{
  /* USER CODE BEGIN WiFi */
	BatterieData_t Data_Batterie;
	char buffer[64];
  /* Infinite loop */
  for(;;)
  {
	  if (xQueueReceive(Q_wifi, &Data_Batterie, portMAX_DELAY) == pdPASS)
	         {
	             // Conversion en chaîne de caractères
	             snprintf(buffer, sizeof(buffer),
	                      "V=%.2fV I=%.2fA BATT=%d%%\n",
						  Data_Batterie.tension_batterie / 1000.0, // Si en mV
						  Data_Batterie.intensite_batterie / 1000.0, // Si en mA
	                      (int)Data_Batterie.batterie_percent);

	             // Envoi via UART vers l'ESP
	             HAL_UART_Transmit(&huart2, (uint8_t *)buffer, strlen(buffer), HAL_MAX_DELAY);
	         }

	         // Petit délai de sécurité
	         vTaskDelay(pdMS_TO_TICKS(100));
	     }

  /* USER CODE END WiFi */
}

/* USER CODE BEGIN Header_INA_Batterry */
/**
* @brief Function implementing the TaskINA_Batterr thread.
* @param argument: Not used
* @retval None
*/

/* USER CODE END Header_INA_Batterry */
void INA_Batterry(void const * argument) // in reality we check after  convertisseur 5v non la batterie
{
  /* USER CODE BEGIN INA_Batterry */
  /* Infinite loop */
	 for(;;)
	    {

	            uint16_t voltage_battery = INA219_ReadBusVoltage(&INA219_Battery);
	            int16_t current_battery = INA219_ReadCurrent(&INA219_Battery);


	            // Calcul du niveau de batterie
	            float battery_percentage = INA219_GetBatteryLife(&INA219_Battery, 4200, 3000); /* (4.2V full - 3.0V empty) RQ: Tension nominale : 3.7V
                                                                                                  Tension maximale de charge : 4.2V

                                                                                                Tension minimale de décharge (cutoff) : 3.0V selon protection*/
	            uint16_t battery_level = (uint16_t)battery_percentage; // Cast to uint16_t to match the queue type

	            BatterieData_t Data_Battery = {
	                .tension_batterie =  voltage_battery ,
	                .intensite_batterie = current_battery,
	                .batterie_percent = battery_level
	            };

	            // vers Q_wifi pour l'application
	            xQueueSend(Q_wifi, &Data_Battery, 0);

	            //vers Q_Bttery pour l'ecran , MPPT , SourceSwitching
	           xQueueOverwrite(Q_BatteryHandle, &battery_level); // xQueueOverwrite() pour Q_Battery ➔ optimisé (pas de file d'attente qui se remplit inutilement).
	        }

	        vTaskDelay(pdMS_TO_TICKS(500));
}
  /* USER CODE END INA_Batterry */


/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
